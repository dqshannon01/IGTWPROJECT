
import java.util.ArrayList;

public class ColorMode {
    
    public ColorMode current;
    public ArrayList<ColorMode> fullModeList=new ArrayList<>();
    private String frameBackground;
    private String textColor;
    private String componentBackground;
    
    ColorMode darkMode = new ColorMode("black", "white", "gray");
    ColorMode lightMode = new ColorMode("light_gray", "black", "gray");
    ColorMode greenMode = new ColorMode("green.darker().darker()", "light_gray", "green.darker()");
    ColorMode tanMode = new ColorMode("orange.darker().darker().darker()", "light_grey", "orange.darker()");
    
    


    ColorMode(String frameBackground, String textColor, String componentBackground){
        this.frameBackground = frameBackground;
        this.textColor = textColor;
        this.componentBackground = componentBackground;
    }

    public String getframeBackground() {
        return frameBackground;
    }

    public void setframeBackground(String frameBackground) {
        this.frameBackground = frameBackground;
    }
    
    public String gettextColor() {
        return textColor;
    }

    public void settextColor(String textColor) {
        this.textColor = textColor;
    }
    
    public String getcomponentBackground() {
        return componentBackground;
    }

    public void setcomponentBackground(String componentBackground) {
        this.componentBackground = componentBackground;
    }

    
}

        