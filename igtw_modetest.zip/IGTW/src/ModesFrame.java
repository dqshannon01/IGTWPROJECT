import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModesFrame extends JFrame implements ActionListener
{
    JButton setupAlertButton,changeTimeZoneButton,displayTimeZoneButton,backButton,homeButton;
    public static JPanel jPanel = new JPanel();
    public ModesFrame()
    {
        jPanel=new JPanel();
        jPanel.setLayout(null);
        jPanel.setBackground(Color.black);

        JLabel heading=new JLabel("Modes",SwingConstants.CENTER);
        heading.setBounds(50,20,200,50);
        heading.setFont(new Font("",Font.BOLD,24));
        heading.setForeground(Color.white);

        setupAlertButton=new JButton("Setup Alert");
        setupAlertButton.setBounds(50,80,200,30);
        setupAlertButton.setFocusable(false);
        setupAlertButton.addActionListener(this);
        setupAlertButton.setForeground(Color.white);
        setupAlertButton.setBackground(Color.gray);
        setupAlertButton.setBorder(BorderFactory.createBevelBorder(0));

        changeTimeZoneButton=new JButton("Change Time Zone");
        changeTimeZoneButton.setBounds(50,130,200,30);
        changeTimeZoneButton.setFocusable(false);
        changeTimeZoneButton.addActionListener(this);
        changeTimeZoneButton.setForeground(Color.white);
        changeTimeZoneButton.setBackground(Color.gray);
        changeTimeZoneButton.setBorder(BorderFactory.createBevelBorder(0));

        displayTimeZoneButton=new JButton("Display All Time Zones");
        displayTimeZoneButton.setBounds(50,180,200,30);
        displayTimeZoneButton.setFocusable(false);
        displayTimeZoneButton.addActionListener(this);
        displayTimeZoneButton.setForeground(Color.white);
        displayTimeZoneButton.setBackground(Color.gray);
        displayTimeZoneButton.setBorder(BorderFactory.createBevelBorder(0));

        backButton=new JButton("Back");
        backButton.setBounds(50,250,80,30);
        backButton.setFocusable(false);
        backButton.addActionListener(this);
        backButton.setForeground(Color.white);
        backButton.setBackground(Color.gray);
        backButton.setBorder(BorderFactory.createBevelBorder(0));

        homeButton=new JButton("Home");
        homeButton.setBounds(170,250,80,30);
        homeButton.setFocusable(false);
        homeButton.addActionListener(this);
        homeButton.setForeground(Color.white);
        homeButton.setBackground(Color.gray);
        homeButton.setBorder(BorderFactory.createBevelBorder(0));
        
        jPanel.add(heading);
        jPanel.add(setupAlertButton);
        jPanel.add(changeTimeZoneButton);
        jPanel.add(displayTimeZoneButton);
        jPanel.add(backButton);
        jPanel.add(homeButton);

        JLayer<JComponent> layer = new JLayer<>(jPanel, MainFrame.layerUI);

        this.add(layer);
        this.setResizable(false);
        this.setSize(300,300);
        this.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource().equals(setupAlertButton))
        {
            this.setVisible(false);

            new AlertFrame();
        }
        if(e.getSource().equals(changeTimeZoneButton))
        {
            this.setVisible(false);
            new TimezoneFrame();
        }
        if(e.getSource().equals(displayTimeZoneButton))
        {
            this.setVisible(false);
            MainFrame.frame.setVisible(true);
        }
        if(e.getSource().equals(backButton) || e.getSource().equals(homeButton))
        {
            this.setVisible(false);
        }

    }
}
